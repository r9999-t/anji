package com.capgemini.crbs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface CRBSDao {

	ResultSet getEmployee(int id) throws SQLException;

	ResultSet isAvailable(int id) throws SQLException;

	int bookConference(int nextInt, String string) throws SQLException;

	ResultSet getConferenceRoom(int id) throws SQLException;

	int cancelConferenceRoom(int id) throws SQLException;

	ResultSet getAllConferenceRooms() throws SQLException;

}
