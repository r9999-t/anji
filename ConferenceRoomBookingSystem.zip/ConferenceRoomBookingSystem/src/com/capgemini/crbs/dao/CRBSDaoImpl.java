package com.capgemini.crbs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.crbs.dbutil.DbUtil;

public class CRBSDaoImpl implements CRBSDao {
	Connection connect=null;
	PreparedStatement ps=null;
	String string;
	int result;
	@Override
	public ResultSet getEmployee(int id) throws SQLException {
		connect=DbUtil.getConnection();
		Statement s=connect.createStatement();
		return s.executeQuery("select * from employee_creation_automation where id="+id+";");
	}
	@Override
	public ResultSet isAvailable(int id) throws SQLException {
		connect=DbUtil.getConnection();
		Statement s=connect.createStatement();
		return s.executeQuery("select count(*) from conference_room_system where conferenceRoomNumber="+id+" and status = 'Available';");
	}
	@Override
	public int bookConference(int nextInt, String name) throws SQLException {
		connect=DbUtil.getConnection();
		string = "update conference_room_system set status = 'Booked', bookedBy = ? where conferenceRoomNumber = ?;";
		ps=connect.prepareStatement(string);
		ps.setInt(2, nextInt);
		ps.setString(1, name);
		result = ps.executeUpdate();
		return result;
	}
	@Override
	public ResultSet getConferenceRoom(int id) throws SQLException {
		connect=DbUtil.getConnection();
		Statement s=connect.createStatement();
		return s.executeQuery("select * from conference_room_system where conferenceRoomNumber="+id+";");
	}
	@Override
	public int cancelConferenceRoom(int id) throws SQLException {
		connect=DbUtil.getConnection();
		string = "update conference_room_system set status = 'Available', bookedBy = ? where conferenceRoomNumber = ?;";
		ps=connect.prepareStatement(string);
		ps.setInt(2, id);
		ps.setString(1, "NA");
		result = ps.executeUpdate();
		return result;
	}
	@Override
	public ResultSet getAllConferenceRooms() throws SQLException {
		connect=DbUtil.getConnection();
		Statement s=connect.createStatement();
		return s.executeQuery("select * from conference_room_system;");
	}

}
