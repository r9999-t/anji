package com.capgemini.crbs.model;

public class ConferenceRoom {
private Integer conferenceRoomNumber;
private String conferenceRoomName;
private String status;
private String bookedBy;
public Integer getConferenceRoomNumber() {
	return conferenceRoomNumber;
}
public void setConferenceRoomNumber(Integer conferenceRoomNumber) {
	this.conferenceRoomNumber = conferenceRoomNumber;
}
public String getConferenceRoomName() {
	return conferenceRoomName;
}
public void setConferenceRoomName(String conferenceRoomName) {
	this.conferenceRoomName = conferenceRoomName;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getBookedBy() {
	return bookedBy;
}
public void setBookedBy(String bookedBy) {
	this.bookedBy = bookedBy;
}
@Override
public String toString() {
	return "ConferenceRoom [conferenceRoomNumber=" + conferenceRoomNumber + ", conferenceRoomName=" + conferenceRoomName
			+ ", status=" + status + ", bookedBy=" + bookedBy + "]";
}
}
