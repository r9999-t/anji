package com.capgemini.crbs.service;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.crbs.model.ConferenceRoom;
import com.capgemini.crbs.model.Employee;

public interface CRBSService {

	Employee getEmployee(int id) throws SQLException;

	boolean isPM(Employee employee);

	int isAvailable(int nextInt) throws SQLException;

	int bookConference(int nextInt, Employee employee) throws SQLException;

	String getConferenceRoom(int nextInt) throws SQLException;

	String cancelConferenceRoom(int nextInt) throws SQLException;

	List<ConferenceRoom> getAllConferenceRooms() throws SQLException;

}
