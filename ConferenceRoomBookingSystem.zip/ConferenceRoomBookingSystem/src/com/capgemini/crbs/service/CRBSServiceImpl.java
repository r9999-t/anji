package com.capgemini.crbs.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.crbs.dao.CRBSDao;
import com.capgemini.crbs.dao.CRBSDaoImpl;
import com.capgemini.crbs.model.ConferenceRoom;
import com.capgemini.crbs.model.Employee;

public class CRBSServiceImpl implements CRBSService {
	CRBSDao dao;
	
	public CRBSServiceImpl() {
		dao = new CRBSDaoImpl();
	}
	
	@Override
	public Employee getEmployee(int id) throws SQLException {
		ResultSet rs =dao.getEmployee(id);
		Employee employee = null;
		while(rs.next()) {
			employee = loadResultSetIntoObject(rs);
		}
		return employee;
	}
	public static Employee loadResultSetIntoObject(ResultSet rs) throws SQLException{
		  Employee employee = new Employee();
		  employee.setId(rs.getInt(1));
		  employee.setFirstName(rs.getString(2));
		  employee.setLastName(rs.getString(3));
		  employee.setSalary(rs.getDouble(4));
		  employee.setJoiningDate(rs.getDate(5));
		  employee.setEmployeeType(rs.getString(6));
		  employee.setContractor(rs.getString(7));
		  employee.setDesignation(rs.getString(8));
		  employee.setMediClaim(rs.getDouble(9));
		  employee.setExperience(rs.getDouble(10));
		  employee.setCertifications(rs.getString(11));
		  employee.setGrade(rs.getString(12));
		  return employee;
		}

	@Override
	public boolean isPM(Employee employee) {
		if("PM".equalsIgnoreCase(employee.getDesignation())) {
			return true;
		}
		return false;
	}

	@Override
	public int isAvailable(int id) throws SQLException {
		ResultSet rs = dao.isAvailable(id);
		while(rs.next()) {
			return rs.getInt(1);
		}
		return 0;
	}

	@Override
	public int bookConference(int id, Employee employee) throws SQLException {
		if(isAvailable(id)>0) {
			return dao.bookConference(id, employee.getFirstName()+" "+employee.getLastName());
		}
		return 0;
	}

	@Override
	public String getConferenceRoom(int id) throws SQLException {
		ResultSet rs = dao.getConferenceRoom(id);
		ConferenceRoom cr = null;
		while(rs.next()) {
			cr = loadCRObject(rs);
			return cr.toString();
		}
		return "Not found";
	}

	private ConferenceRoom loadCRObject(ResultSet rs) throws SQLException {
		ConferenceRoom cr = new ConferenceRoom();
		cr.setConferenceRoomNumber(rs.getInt(1));
		cr.setConferenceRoomName(rs.getString(2));
		cr.setStatus(rs.getString(3));
		cr.setBookedBy(rs.getString(4));
		return cr;
	}

	@Override
	public String cancelConferenceRoom(int id) throws SQLException {
		int rows = dao.cancelConferenceRoom(id);
		if(rows>0) {
			return "Success";
		}
		return "Failed";
	}

	@Override
	public List<ConferenceRoom> getAllConferenceRooms() throws SQLException {
		ResultSet rs = dao.getAllConferenceRooms();
		List<ConferenceRoom> list = new ArrayList<ConferenceRoom>();
		while(rs.next()) {
			ConferenceRoom cr = loadCRObject(rs);
			list.add(cr);
		}
		return list;
	}
}
