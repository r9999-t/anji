package com.capgemini.crbs.ui;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.crbs.model.ConferenceRoom;
import com.capgemini.crbs.model.Employee;
import com.capgemini.crbs.service.CRBSService;
import com.capgemini.crbs.service.CRBSServiceImpl;

public class ConferenceRoomBookingSystem {
public static void main(String[] args) {
	CRBSService service = new CRBSServiceImpl();
	Scanner scan = new Scanner(System.in);
	
	try {
		Employee employee = getEmployee(service,scan);
		while(true) {			
			showMenu();
			System.out.println("enter your choice: ");
			switch(scan.nextInt()) {
			case 1:
				if(service.isPM(employee)) {
					System.out.println("Enter conference room id");
					if(service.bookConference(scan.nextInt(), employee)>0) {
						System.out.println("Successfully booked");
					}
					else {
						System.out.println("Conference room already booked or not available");
					}
				}
				else {
					System.out.println("Only Project Manager can book a room");
				}
				break;
			case 2:
				System.out.println("Enter conference room id: ");
				System.out.println(service.getConferenceRoom(scan.nextInt()));
				break;
			case 3:
				if(service.isPM(employee)) {
				System.out.println("Enter conference room id: ");
				System.out.println(service.cancelConferenceRoom(scan.nextInt()));
			}
				else {
					System.out.println("Only Project Manager can cancel/relieve a room");
				}
				break;
			case 4:
				List<ConferenceRoom> list = service.getAllConferenceRooms();
				int i=0;
				if(!list.isEmpty()) {
					System.out.println("Conference Rooms");
					while(i < list.size()) {
					System.out.println(list.get(i).toString());
					i++;
					}
				}
				else {
					System.out.println("No rooms found");
				}
				
				break;
			case 5:
				System.exit(0);
			default:
				break;
			}
		}
	}
	catch(Exception e) {
		System.out.println(e);
		System.exit(0);
	}
}

private static Employee getEmployee(CRBSService service, Scanner scan) throws SQLException {
	Employee emp = null;
	while(emp==null) {
		System.out.println("Enter employee id");
		emp = service.getEmployee(scan.nextInt());
		if(emp==null) {
			System.out.println("Employee not found");
		}
	}
	return emp;
}

private static void showMenu() {
	System.out.println("Conference Room Booking System\n*********************");
	System.out.println("1.Book a Conference room\n2.Check a conference room\n3.Relieve or Cancel a conference room\n4.Check all conference rooms\n5.Exit");
}
}
