package com.capgemini.eca.models;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Employee {
	private int id;
	private String firstName;
	private String lastName;
	private Double salary;
	private String grade;
	private Date joiningDate;
	private String employeeType;
	private String contractor;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public Date getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(Date date) {
		this.joiningDate = date;
	}
	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	public String getContractor() {
		return contractor;
	}
	public void setContractor(String contractor) {
		this.contractor = contractor;
	}
	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");  
	    String strDate = formatter.format(joiningDate);
		return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", grade=" + grade + ", joiningDate=" + strDate + ", employeeType=" + employeeType
				+ ", Contractor=" + contractor + "]";
	}
	
}
