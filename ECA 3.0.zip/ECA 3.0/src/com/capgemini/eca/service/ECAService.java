package com.capgemini.eca.service;

import java.util.List;

import com.capgemini.eca.models.Employee;

public interface ECAService {

	public int createEmployee(Employee employee);

	public String getEmployeeDetails(int id);

	public List<Employee> getAllEmployees();

	public int getCount();

	public Double getContractSalary(double ratePerhour, double numberOfHours);

}
