package com.capgemini.eca.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.eca.models.Employee;

public class ECAServiceImpl implements ECAService {
	private static int employeeId;
	private static List<Employee> employeeList;
	
	public ECAServiceImpl() {
		employeeId = 1;
		employeeList = new ArrayList<>();
	}
	@Override
	public int createEmployee(Employee employee) {
		employee.setId(employeeId++);
		employeeList.add(employee);
		return employee.getId();
	}
	@Override
	public String getEmployeeDetails(int id) {
		if(id > 0 || id < employeeList.size()) {
			Employee employee = new Employee();
			for (Employee emp : employeeList) {
				if(emp.getId() == id) {
					employee = emp;
					break;
				}
			}
			return employee.toString();
		}
		else {
			return "Employee not Found";
		}
	}
	@Override
	public List<Employee> getAllEmployees() {
		return employeeList;
	}
	@Override
	public int getCount() {
		return employeeList.size();
	}
	@Override
	public Double getContractSalary(double ratePerhour, double numberOfHours) {
		return ratePerhour*numberOfHours;
	}

}
