import static org.junit.jupiter.api.Assertions.assertEquals;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.runners.MethodSorters;

import com.capgemini.eca.models.Employee;
import com.capgemini.eca.service.ECAService;
import com.capgemini.eca.service.ECAServiceImpl;


//@FixMethodOrder(MethodSorters.DEFAULT)
class ECATest{
	private static ECAService service;
	
	
	@BeforeAll 
	static void before() {
		  service = new ECAServiceImpl(); 
	  }
	 
	
	@Test
	void myATest() throws ParseException {
		//creating a permanent employee
		Employee employee = new Employee();
		employee.setFirstName("Ram");
		employee.setLastName("Raj");
		employee.setSalary(10000.00);
		employee.setGrade("A");
		String date="23-07-2020";
		DateFormat format = new SimpleDateFormat("dd-MM-yyyy");
		Date joiningDate = format.parse(date);
		employee.setJoiningDate(joiningDate);
		employee.setEmployeeType("Permenant");
		employee.setContractor("NA");
		int expectedId = 1;
		assertEquals(expectedId, service.createEmployee(employee));
	}
	
	@Test
	void myBTest() {
		String expected = "Employee [id=1, firstName=Ram, lastName=Raj, salary=10000.0, grade=A, joiningDate=23-07-2020, employeeType=Permenant, Contractor=NA]";
		assertEquals(expected, service.getEmployeeDetails(1));
	}
	
	@Test
	void myCTest() throws ParseException {
		//creating a contract employee
		Employee employee = new Employee();
		employee.setFirstName("Veer");
		employee.setLastName("Raj");
		employee.setSalary(service.getContractSalary(100, 20));
		employee.setGrade("A");
		String date="30-07-2020";
		DateFormat format = new SimpleDateFormat("dd-MM-yyyy");
		Date joiningDate = format.parse(date);
		employee.setJoiningDate(joiningDate);
		employee.setEmployeeType("Contract Basis");
		employee.setContractor("Ram");
		int expectedId = 2;
		assertEquals(expectedId, service.createEmployee(employee));
	}
	
	@Test
	void myDTest() {
		String expected = "Employee [id=2, firstName=Veer, lastName=Raj, salary=2000.0, grade=A, joiningDate=30-07-2020, employeeType=Contract Basis, Contractor=Ram]";
		assertEquals(expected, service.getEmployeeDetails(2));
	}
	
	@Test
	void myETest() {
		int expectedSize = 2;
		List<Employee> empList = service.getAllEmployees();
		assertEquals(expectedSize, empList.size());
	}
	
	@Test
	void myFTest() {
		int expectedCount = 2;
		assertEquals(expectedCount, service.getCount());
	}
	
	@Test
	void myGTest() {
		double expected = 1500.0;
		double ratePerHour = 100;
		double numberOfHours = 15;
		assertEquals(expected, service.getContractSalary(ratePerHour, numberOfHours));
	}
}
