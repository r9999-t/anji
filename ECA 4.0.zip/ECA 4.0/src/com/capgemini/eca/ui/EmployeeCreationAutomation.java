package com.capgemini.eca.ui;

import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import com.capgemini.eca.models.Employee;
import com.capgemini.eca.service.ECAService;
import com.capgemini.eca.service.ECAServiceImpl;

public class EmployeeCreationAutomation {
	public static void main(String[] args) throws ParseException {
		ECAService service = new ECAServiceImpl();
		Scanner scanner = new Scanner(System.in);
		int input;
		while(true) {
			printMenu();
			input = scanner.nextInt();
			switch (input) {
			case 1: 
				Employee employee = new Employee();
				System.out.println("Enter first name: ");
				employee.setFirstName(scanner.next());
				System.out.println("Enter last name: ");
				employee.setLastName(scanner.next());
				System.out.println("Enter grade");
				employee.setGrade(scanner.next());
				System.out.println("Enter joining date in dd-mm-yyyy format: ");
				String date=scanner.next();
				DateFormat format = new SimpleDateFormat("dd-MM-yyyy");
				Date joiningDate = format.parse(date);
				employee.setJoiningDate(joiningDate);
				System.out.println("Enter employee type(Permenant as P, Contract basis C): ");
				employee.setEmployeeType(scanner.next());
				setEmployeeTypeAndDesignation(scanner, service, employee);
				System.out.println("Employee created with id: "+ service.createEmployee(employee));
				break;
			case 2:
				System.out.println("Enter employee id: ");
				System.out.println(service.getEmployeeDetails(scanner.nextInt()));
				break;
			case 3:
				System.out.println("All Employees:\n");
				printEmployeeList(service.getAllEmployees());
				break;
			case 4:
				System.out.println("Total employees in system: "+service.getCount());
				break;
			case 5:
				System.out.println("Enter contractor name: ");
				printEmployeeList(service.getEmployeesByContractor(scanner.next()));
				break;
			case 6:
				System.out.println("Select Category: \n1.Permenant\n2.Contract Basis");
				printEmployeeList(service.getEmployeesByCategory(scanner.nextInt()));
				break;
			case 7:
				System.out.println("Enter the employee id");
				String response = service.provideMediClaim(scanner.nextInt());
				System.out.println(response);
				break;
			case 8:
				scanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("Invalid choice");
				break;
			}
		}
	}

	private static void setEmployeeTypeAndDesignation(Scanner scanner, ECAService service, Employee employee) {
		if("P".equalsIgnoreCase(employee.getEmployeeType())) {
			employee.setEmployeeType("Permenant");
			employee.setContractor("NA");
			System.out.println("Enter salary: ");
			employee.setSalary(scanner.nextDouble());
			while(employee.getDesignation()==null) {
				System.out.println("Select designation:\n1. Project Manager\n2. Technical Associate");
				switch(scanner.nextInt()) {
				case 1:
					employee.setDesignation("Project Manager");
					break;
				case 2:
					employee.setDesignation("Technical Associate");
					break;
				default:
					System.out.println("Invalid choice");
					break;
				}
			}
		}
		else if("C".equalsIgnoreCase(employee.getEmployeeType())) {
			employee.setEmployeeType("Contract Basis");
			System.out.println("Enter contractor name: ");
			employee.setContractor(scanner.next());
			employee.setSalary(generateContractEmployeeSalary(scanner, service));
			employee.setDesignation("Technical Associate");
		}
	}

	private static void printEmployeeList(List<Employee> employeeList) {
		if(employeeList.size()>0) {
			for (Employee emp : employeeList) {
				System.out.println(emp.toString());
			}
		}
		else {
			System.out.println("No Employees Found");
		}
		
	}

	private static Double generateContractEmployeeSalary(Scanner scanner, ECAService service) {
		System.out.println("Enter rate per hour: ");
		double ratePerhour = scanner.nextDouble();
		System.out.println("Enter number of hours worked: ");
		double numberOfHours = scanner.nextDouble();
		return service.getContractSalary(ratePerhour, numberOfHours);
	}

	private static final void printMenu() {
		System.out.println("***Employee Creation Automation***");
		System.out.println("1.Create Employee\n2.View Employee\n3.View All\n4.Count of Total Employees Created\n5.Get Employees by Contractor\n6.Get Employees By Category\n7.Provide MediClaim\n8.Exit");
		
	}
}
