package com.capgemini.eca.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.capgemini.eca.models.Employee;

public class ECAServiceImpl implements ECAService {
	private static int employeeId;
	private static List<Employee> employeeList;
	
	public ECAServiceImpl() {
		employeeId = 1;
		employeeList = new ArrayList<>();
	}
	@Override
	public int createEmployee(Employee employee) {
		employee.setId(employeeId++);
		employeeList.add(employee);
		return employee.getId();
	}
	@Override
	public String getEmployeeDetails(int id, boolean salary) {
		if(id > 0 || id < employeeList.size()) {
			Employee employee = new Employee();
			for (Employee emp : employeeList) {
				if(emp.getId() == id) {
					employee = emp;
					break;
				}
			}
			if(salary) {
				return "Salary of the Employee: "+employee.getSalary();
			}
			return employee.toString();
		}
		else {
			return "Employee not Found";
		}
	}
	@Override
	public List<Employee> getAllEmployees() {
		return employeeList;
	}
	@Override
	public int getCount() {
		return employeeList.size();
	}
	@Override
	public Double getContractSalary(double ratePerhour, double numberOfHours) {
		if(numberOfHours>40) {
			return (40*ratePerhour)+((numberOfHours-40)*(ratePerhour*2));
		}
		else {
		return ratePerhour*numberOfHours;
		}
	}
	@Override
	public List<Employee> getEmployeesByContractor(String contractorName) {
		List<Employee> employeeListUnderContractor = employeeList.stream().filter(item -> contractorName.equalsIgnoreCase(item.getContractor())).collect(Collectors.toList());
		return employeeListUnderContractor;
	}
	@Override
	public List<Employee> getEmployeesByCategory(int selection) {
		if(selection == 1) {
			return employeeList.stream().filter(item -> "Permenant".equalsIgnoreCase(item.getEmployeeType())).collect(Collectors.toList());
		}
		else if(selection == 2) {
			return employeeList.stream().filter(item -> "Contract Basis".equalsIgnoreCase(item.getEmployeeType())).collect(Collectors.toList());
		}
		else {
			return null;
		}
	}
	@Override
	public String provideMediClaim(int id) {
		if(id > 0 || id < employeeList.size()) {
			Employee employee = new Employee();
			for (Employee emp : employeeList) {
				if(emp.getId() == id) {
					employee = emp;
					break;
				}
			}
			return setMedicalClaim(employee);
		}
		else {
			return "Employee not Found";
		}
	}
	private String setMedicalClaim(Employee employee) {
		if("Permenant".equalsIgnoreCase(employee.getEmployeeType())){
			double medicalClaim = 0;
			if("Project Manager".equalsIgnoreCase(employee.getDesignation())) {
				medicalClaim = employee.getSalary()*12;
				employee.setMediClaim(medicalClaim);
				updateList(employee);
				return "Medical Claim provided of "+employee.getMediClaim()+" to Employee with id = "+employee.getId();
			}
			else if("Technical Associate".equalsIgnoreCase(employee.getDesignation())) {
				medicalClaim = employee.getSalary()*12*2;
				employee.setMediClaim(medicalClaim);
				updateList(employee);
				return "Medical Claim provided of "+employee.getMediClaim()+" to Employee with id = "+employee.getId();
			}
			else {
				return "Employee has invalid designation";
			}
		}
		else if("Contract Basis".equalsIgnoreCase(employee.getEmployeeType())) {
			return "Medical Claim cant be provided to Contract Basis employee.";
		}
		else {
			return "Invalid employee type";
		}
	}
	private void updateList(Employee employee) {
		employeeList.removeIf(item->item.getId()==employee.getId());
		employeeList.add(employee);
	}
	@Override
	public Double getPermenantSalary(Employee employee) {
		if(employee.getDesignation().equals("PM")) {
			return 10000*employee.getExperience();
		}
		else {
			return 5000*employee.getExperience()+(1000*employee.getCertifications());
		}
	}

}
