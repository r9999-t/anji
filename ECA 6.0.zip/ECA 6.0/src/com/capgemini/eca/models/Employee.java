package com.capgemini.eca.models;

import java.util.Date;

public class Employee {
	private int id;
	private String firstName;
	private String lastName;
	private Double salary;
	private String grade;
	private Date joiningDate;
	private String employeeType;
	private String contractor;
	private String designation;
	private double mediClaim;
	private double experience;
	private String certifications;
	
	public double getExperience() {
		return experience;
	}
	public void setExperience(double experience) {
		this.experience = experience;
	}
	public String getCertifications() {
		return certifications;
	}
	public void setCertifications(String certifications) {
		this.certifications = certifications;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public Date getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(Date date) {
		this.joiningDate = date;
	}
	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	public String getContractor() {
		return contractor;
	}
	public void setContractor(String contractor) {
		this.contractor = contractor;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getMediClaim() {
		return mediClaim;
	}
	public void setMediClaim(double mediClaim) {
		this.mediClaim = mediClaim;
	}
	
	@Override
	public String toString() {
		if(designation.equals("TA-C")) {
			return " Contractor = "+contractor+", Employee Name="+ firstName+" " +lastName+", Designation="+designation;
		}
		else {
			return " Employee Id = "+id+", Employee Name="+ firstName+" " +lastName+", Designation="+designation+", Experience="+experience+" yrs.";
		}
	}	
}
