package com.capgemini.eca.service;

import java.util.Arrays;
import java.util.List;

import com.capgemini.eca.models.Employee;

public class CertificationImpl implements Certification {

	@Override
	public List<String> getCertification(Employee employee) {
		return Arrays.asList(employee.getCertifications().split(","));
	}

}
