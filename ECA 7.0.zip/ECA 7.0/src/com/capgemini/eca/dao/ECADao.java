package com.capgemini.eca.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.eca.models.Employee;

public interface ECADao {
	int insertEmployee(Employee employee) throws SQLException;
	ResultSet getEmployee(int id) throws SQLException;
	ResultSet getAllEmployees() throws SQLException;
	int updateMediClaim(Employee employee) throws SQLException;
}
