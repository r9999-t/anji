package com.capgemini.eca.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.eca.dbutil.DbUtil;
import com.capgemini.eca.models.Employee;

public class ECADaoImpl implements ECADao {
	Connection connect=null;
	PreparedStatement ps=null;
	String string;
	int result;
	@Override
	public int insertEmployee(Employee employee) throws SQLException {
		connect=DbUtil.getConnection();
		string = "insert into employee_creation_automation(first_name,last_name,grade,salary,joining_date,employee_type,contractor,designation,medi_claim,experience,certifications) values(?,?,?,?,?,?,?,?,?,?,?);";
		ps=connect.prepareStatement(string);
		ps.setString(1, employee.getFirstName());
		ps.setString(2, employee.getLastName());
		ps.setString(3, employee.getGrade());
		ps.setDouble(4, employee.getSalary());
		ps.setDate(5, new Date(employee.getJoiningDate().getTime()));
		ps.setString(6, employee.getEmployeeType());
		ps.setString(7, employee.getContractor());
		ps.setString(8, employee.getDesignation());
		ps.setDouble(9, employee.getMediClaim());
		ps.setDouble(10, employee.getExperience());
		ps.setString(11, employee.getCertifications());
		result = ps.executeUpdate();
		return result;
	}

	@Override
	public ResultSet getEmployee(int id) throws SQLException {
		connect=DbUtil.getConnection();
		Statement s=connect.createStatement();
		return s.executeQuery("select * from employee_creation_automation where id="+id+";");
	}

	@Override
	public ResultSet getAllEmployees() throws SQLException {
		connect=DbUtil.getConnection();
		Statement s=connect.createStatement();
		return s.executeQuery("select * from employee_creation_automation;");
	}

	@Override
	public int updateMediClaim(Employee employee) throws SQLException {
		connect=DbUtil.getConnection();
		string = "update employee_creation_automation set medi_claim = ? where id = ?;";
		ps=connect.prepareStatement(string);
		ps.setDouble(1, employee.getMediClaim());
		ps.setInt(2, employee.getId());
		result = ps.executeUpdate();
		return result;
	}

}
