package com.capgemini.eca.service;

import java.util.List;

import com.capgemini.eca.models.Employee;

public interface Certification {
	List<String> getCertification(Employee employee);
}
