package com.capgemini.eca.service;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.eca.models.Employee;

public interface ECAService {

	public int createEmployee(Employee employee) throws SQLException;

	public String getEmployeeDetails(int id, boolean salary) throws SQLException, IllegalArgumentException, IllegalAccessException;

	public List<Employee> getAllEmployees() throws SQLException;

	public int getCount() throws SQLException;

	public Double getContractSalary(double ratePerhour, double numberOfHours);

	public List<Employee> getEmployeesByContractor(String contractorName) throws SQLException;

	public List<Employee> getEmployeesByCategory(int selection) throws SQLException;

	public String provideMediClaim(int id) throws SQLException;

	public Double getPermenantSalary(Employee employee);

	public String getCertifications(int id) throws SQLException;

}
