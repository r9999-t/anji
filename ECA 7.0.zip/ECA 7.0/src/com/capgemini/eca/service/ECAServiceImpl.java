package com.capgemini.eca.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.capgemini.eca.dao.ECADao;
import com.capgemini.eca.dao.ECADaoImpl;
import com.capgemini.eca.models.Employee;

public class ECAServiceImpl implements ECAService {
	private static int employeeId;
	private static List<Employee> employeeList;
	Certification certificationService;
	ECADao dao;
	public ECAServiceImpl() {
		employeeId = 1;
		employeeList = new ArrayList<>();
		dao=new ECADaoImpl();
		certificationService = new CertificationImpl();
	}
	@Override
	public int createEmployee(Employee employee) throws SQLException {
		return dao.insertEmployee(employee);
	}
	@Override
	public String getEmployeeDetails(int id, boolean salary) throws SQLException, IllegalArgumentException, IllegalAccessException {
		ResultSet rs =dao.getEmployee(id);
		Employee employee = null;
		while(rs.next()) {
			employee = loadResultSetIntoObject(rs);
		}
		if(employee !=null) {
			if(salary) {
				return "Salary of the Employee: "+employee.getSalary();
			}
			return employee.toString();
		}
		else {
			return "Employee not Found";
		}
	}
	public static Employee loadResultSetIntoObject(ResultSet rs) throws SQLException{
	  Employee employee = new Employee();
	  employee.setId(rs.getInt(1));
	  employee.setFirstName(rs.getString(2));
	  employee.setLastName(rs.getString(3));
	  employee.setSalary(rs.getDouble(4));
	  employee.setJoiningDate(rs.getDate(5));
	  employee.setEmployeeType(rs.getString(6));
	  employee.setContractor(rs.getString(7));
	  employee.setDesignation(rs.getString(8));
	  employee.setMediClaim(rs.getDouble(9));
	  employee.setExperience(rs.getDouble(10));
	  employee.setCertifications(rs.getString(11));
	  employee.setGrade(rs.getString(12));
	  return employee;
	}
	@Override
	public List<Employee> getAllEmployees() throws SQLException {
		ResultSet rs= dao.getAllEmployees();
		List<Employee> allEmployees=new ArrayList<Employee>();
		while(rs.next()) {
			Employee employee = loadResultSetIntoObject(rs);
			allEmployees.add(employee);
		}
		return allEmployees;
	}
	@Override
	public int getCount() throws SQLException {
		ResultSet rs= dao.getAllEmployees();
		List<Employee> allEmployees=new ArrayList<Employee>();
		while(rs.next()) {
			Employee employee = loadResultSetIntoObject(rs);
			allEmployees.add(employee);
		}
		return allEmployees.size();
	}
	@Override
	public Double getContractSalary(double ratePerhour, double numberOfHours) {
		if(numberOfHours>40) {
			return (40*ratePerhour)+((numberOfHours-40)*(ratePerhour*2));
		}
		else {
		return ratePerhour*numberOfHours;
		}
	}
	@Override
	public List<Employee> getEmployeesByContractor(String contractorName) throws SQLException {
		ResultSet rs= dao.getAllEmployees();
		List<Employee> allEmployees=new ArrayList<Employee>();
		while(rs.next()) {
			Employee employee = loadResultSetIntoObject(rs);
			allEmployees.add(employee);
		}
		List<Employee> employeeListUnderContractor = allEmployees.stream().filter(item -> contractorName.equalsIgnoreCase(item.getContractor())).collect(Collectors.toList());
		return employeeListUnderContractor;
	}
	@Override
	public List<Employee> getEmployeesByCategory(int selection) throws SQLException {
		ResultSet rs= dao.getAllEmployees();
		List<Employee> allEmployees=new ArrayList<Employee>();
		while(rs.next()) {
			Employee employee = loadResultSetIntoObject(rs);
			allEmployees.add(employee);
		}
		if(selection == 1) {
			return allEmployees.stream().filter(item -> "Permenant".equalsIgnoreCase(item.getEmployeeType())).collect(Collectors.toList());
		}
		else if(selection == 2) {
			return allEmployees.stream().filter(item -> "Contract Basis".equalsIgnoreCase(item.getEmployeeType())).collect(Collectors.toList());
		}
		else {
			return null;
		}
	}
	@Override
	public String provideMediClaim(int id) throws SQLException {
		ResultSet rs =dao.getEmployee(id);
		Employee employee = null;
		while(rs.next()) {
			employee = loadResultSetIntoObject(rs);
		}
		if(employee !=null) {
			return setMedicalClaim(employee);
		}
		else {
			return "Employee not Found";
		}
	}
	private String setMedicalClaim(Employee employee) throws SQLException {
		if("Permenant".equalsIgnoreCase(employee.getEmployeeType())){
			double medicalClaim = 0;
			if("PM".equalsIgnoreCase(employee.getDesignation())) {
				medicalClaim = employee.getSalary()*12;
				employee.setMediClaim(medicalClaim);
				int rows = dao.updateMediClaim(employee);
				if(rows>0) {
					return "Medical Claim provided of "+employee.getMediClaim()+" to Employee with id = "+employee.getId();
				}
				else {
					return "Error providing claim";
				}
			}
			else if("TA-P".equalsIgnoreCase(employee.getDesignation())) {
				medicalClaim = employee.getSalary()*12*2;
				employee.setMediClaim(medicalClaim);
				int rows = dao.updateMediClaim(employee);
				if(rows>0) {
					return "Medical Claim provided of "+employee.getMediClaim()+" to Employee with id = "+employee.getId();
				}
				else {
					return "Error providing claim";
				}
			}
			else {
				return "Employee has invalid designation";
			}
		}
		else if("Contract Basis".equalsIgnoreCase(employee.getEmployeeType())) {
			return "Medical Claim cant be provided to Contract Basis employee.";
		}
		else {
			return "Invalid employee type";
		}
	}
	@Override
	public Double getPermenantSalary(Employee employee) {
		if(employee.getDesignation().equals("PM")) {
			return 10000*employee.getExperience();
		}
		else {
			return 5000*employee.getExperience()+(1000*certificationService.getCertification(employee).size());
		}
	}
	@Override
	public String getCertifications(int id) throws SQLException {
		ResultSet rs =dao.getEmployee(id);
		Employee employee = null;
		while(rs.next()) {
			employee = loadResultSetIntoObject(rs);
		}
		if(employee !=null) {
			if(employee.getDesignation().equals("TA-C")|| null == employee.getCertifications()) {
				return "No Certifications.";
			}
			return certificationService.getCertification(employee).toString();
		}
		return "Invalid Id";
	}

}
