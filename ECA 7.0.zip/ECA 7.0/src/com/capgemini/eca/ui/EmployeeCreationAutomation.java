package com.capgemini.eca.ui;

import java.util.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import com.capgemini.eca.models.Employee;
import com.capgemini.eca.service.ECAService;
import com.capgemini.eca.service.ECAServiceImpl;

public class EmployeeCreationAutomation {
	public static void main(String[] args) throws ParseException, SQLException, IllegalArgumentException, IllegalAccessException {
		ECAService service = new ECAServiceImpl();
		Scanner scanner = new Scanner(System.in);
		int input;
		while(true) {
			printMenu();
			input = scanner.nextInt();
			try {
				switch (input) {
				case 1: 
					Employee employee = new Employee();
					System.out.println("Enter first name: ");
					employee.setFirstName(scanner.next());
					System.out.println("Enter last name: ");
					employee.setLastName(scanner.next());
					System.out.println("Enter grade");
					employee.setGrade(scanner.next());
					System.out.println("Enter joining date in dd-mm-yyyy format: ");
					String date=scanner.next();
					DateFormat format = new SimpleDateFormat("dd-MM-yyyy");
					Date joiningDate = format.parse(date);
					employee.setJoiningDate(joiningDate);
					System.out.println("Enter employee type(Permenant as P, Contract basis C): ");
					employee.setEmployeeType(scanner.next());
					setEmployeeTypeAndDesignation(scanner, service, employee);
						if(service.createEmployee(employee)==1) {
							System.out.println("Employee created");
						}
						else {
							System.out.println("Employee Creation failed");
						}
					break;
				case 2:
					System.out.println("Enter employee id: ");
					System.out.println(service.getEmployeeDetails(scanner.nextInt(),false));
					break;
				case 3:
					System.out.println("All Employees:\n");
					printEmployeeList(service.getAllEmployees());
					break;
				case 4:
					System.out.println("Total employees in system: "+service.getCount());
					break;
				case 5:
					System.out.println("Enter contractor name: ");
					printEmployeeList(service.getEmployeesByContractor(scanner.next()));
					break;
				case 6:
					System.out.println("Select Category: \n1.Permenant\n2.Contract Basis");
					printEmployeeList(service.getEmployeesByCategory(scanner.nextInt()));
					break;
				case 7:
					System.out.println("Enter the employee id");
					String response = service.provideMediClaim(scanner.nextInt());
					System.out.println(response);
					break;
				case 8:
					System.out.println("Enter employee id: ");
					System.out.println(service.getEmployeeDetails(scanner.nextInt(),true));
					break;
				case 9:
					System.out.println("Enter the employee id: ");
					System.out.println("Certifications: "+service.getCertifications(scanner.nextInt()));
					break;
				case 10:
					scanner.close();
					System.exit(0);
					break;
				default:
					System.out.println("Invalid choice");
					break;
				}
			}
			catch(Exception e) {
				System.out.println(e);
			}
		}
	}

	private static void setEmployeeTypeAndDesignation(Scanner scanner, ECAService service, Employee employee) {
		if("P".equalsIgnoreCase(employee.getEmployeeType())) {
			employee.setEmployeeType("Permenant");
			employee.setContractor("NA");
			while(employee.getDesignation()==null) {
				System.out.println("Select designation:\n1. Project Manager\n2. Technical Associate");
				switch(scanner.nextInt()) {
				case 1:
					employee.setDesignation("PM");
					System.out.println("Did employee has the PMI certification? (Y/N)");
					if(scanner.next()=="Y") {
						employee.setCertifications("PMI");
					}
					break;
				case 2:
					employee.setDesignation("TA-P");
					System.out.println("Enter the number of certifications seperated by comma(',')");
					employee.setCertifications(scanner.next());
					break;
				default:
					System.out.println("Invalid choice");
					break;
				}
			}
			System.out.println("Enter experience: ");
			employee.setExperience(scanner.nextDouble());
			employee.setSalary(service.getPermenantSalary(employee));
		}
		else if("C".equalsIgnoreCase(employee.getEmployeeType())) {
			employee.setEmployeeType("Contract Basis");
			System.out.println("Enter contractor name: ");
			employee.setContractor(scanner.next());
			employee.setSalary(generateContractEmployeeSalary(scanner, service));
			employee.setDesignation("TA-C");
		}
	}

	private static void printEmployeeList(List<Employee> employeeList) {
		if(employeeList.size()>0) {
			for (Employee emp : employeeList) {
				System.out.println(emp.toString());
			}
		}
		else {
			System.out.println("No Employees Found");
		}
		
	}

	private static Double generateContractEmployeeSalary(Scanner scanner, ECAService service) {
		System.out.println("Enter rate per hour: ");
		double ratePerhour = scanner.nextDouble();
		System.out.println("Enter number of hours worked: ");
		double numberOfHours = scanner.nextDouble();
		return service.getContractSalary(ratePerhour, numberOfHours);
	}

	private static final void printMenu() {
		System.out.println("***Employee Creation Automation***");
		System.out.println("1.Create Employee\n2.View Employee\n3.View All\n4.Count of Total Employees Created\n5.Get Employees by Contractor\n6.Get Employees By Category\n7.Provide MediClaim\n8.Get Salary of Employee\n9.Get the certifications of an employee\n10.Exit");
	}
}
