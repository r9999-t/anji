package com.cg.VIMApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VimApplication {

	public static void main(String[] args) {
		SpringApplication.run(VimApplication.class, args);
	}

}
