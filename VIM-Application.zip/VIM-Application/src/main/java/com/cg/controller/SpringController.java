package com.cg.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.beans.CarDTO;
import com.cg.dao.impl.JDBCCarDAO;
@RequestMapping("/vim")
@Controller
public class SpringController {

	@Autowired
	JDBCCarDAO carDAO;
	
	@RequestMapping(value = "getAll",method = RequestMethod.GET)
	public String viewCarList(Model model) {
		List<CarDTO> cars = carDAO.findAll();
		System.out.println(cars);
		model.addAttribute("carList", cars);
		
		return "carList";
	}
	
	@RequestMapping(value = "addCar")
	public String addCars(Model model) {
		return "carForm";
	}
	
	@RequestMapping(value = "saveDetails")
	public String saveValues(@RequestParam("make")String make,@RequestParam("model")String model,@RequestParam("modelYear")String year,Model m) {
	
		carDAO.create(new CarDTO(make, model, year));
		
		
		//System.out.println(We are at);
		//CarDAO carDAO1=new JDBCCarDAO();
		List<CarDTO> cars = carDAO.findAll();
		System.out.println(cars);
		m.addAttribute("carList", cars);
		
		return "carList";
	
	}
	
	@RequestMapping(value = "editCar/{id}")
	public String editCars(@PathVariable("id")int id,Model m) {
		System.out.println(id);
		//CarDAO carDAO=new JDBCCarDAO();
		CarDTO dto=new CarDTO();
		
		dto=carDAO.findById(id);
		m.addAttribute("car", dto);
		System.out.println("We are int EditCars");
		return "carForm2";
	}
	
	@PostMapping(value = "updateCar")
	public String updateCars(@RequestParam("id")int id,@RequestParam("make")String make,@RequestParam("model")String model,@RequestParam("modelYear")String modelYear,Model m) {
		CarDTO car =new CarDTO();
		car.setId(id);
		car.setMake(make);
		car.setModel(model);
		car.setModelYear(modelYear);
		carDAO.update(car);
		
		List<CarDTO> cars = carDAO.findAll();
		System.out.println(cars);
		m.addAttribute("carList", cars);
		
		return "carList";
	}
	
	@RequestMapping(value = "delCar")
	public String removeCar(HttpServletRequest request) {
		
	
		String ids[] = request.getParameterValues("id");
    	
    	carDAO.delete(ids);
    	 
    	 
    	 List<CarDTO> cars = carDAO.findAll();
     	
			//Set the found cars in request with name as 'carList'
     	request.setAttribute("carList", cars);
    	
		//Set the found car in request with name as 'car'
    	//request.setAttribute("car", carDTO);
     	return "carList";
    	
    	
		
	}
	
	
}
