package com.cg.VIMApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VimApplicationTests {

	@Test
	void contextLoads() {
	}

}
