package com.cg.beans;

import java.io.Serializable;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "car")
public class CarDTO implements Serializable{

		@Id
		@GeneratedValue
		private int id;
		
		@Column(name = "make",length = 30)
	    private String make;
		@Column(name = "model",length = 30)
	    private String model;
		@Column(name = "year",length = 30)
	    private String modelYear;

	    public CarDTO()
	    {
	        //TODO 1 initialize id to -1 and rest of the member variables to a blank string
			id = -1;
			make = model = modelYear = "Not Specified";
	    }
	    
	    

	    public CarDTO(String make, String model, String modelYear) {
			super();
			this.make = make;
			this.model = model;
			this.modelYear = modelYear;
		}

	    


		public CarDTO(int id, String make, String model, String modelYear) {
			super();
			this.id = id;
			this.make = make;
			this.model = model;
			this.modelYear = modelYear;
		}



		//TODO 2 Implement the setter and getter methods
		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getMake() {
			return make;
		}

		public void setMake(String make) {
			this.make = make;
		}

		public String getModel() {
			return model;
		}

		public void setModel(String model) {
			this.model = model;
		}

		public String getModelYear() {
			return modelYear;
		}

		public void setModelYear(String modelYear) {
			this.modelYear = modelYear;
		}
	
}
