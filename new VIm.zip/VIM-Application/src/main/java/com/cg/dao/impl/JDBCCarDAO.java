package com.cg.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.CarDTO;
import com.cg.dao.CarDAO;

//TODO 1 Import appropriate classes based on following TODOs


// TODO 2 Implement appropriate Interface
@Service
@Transactional
public class JDBCCarDAO  {
	// TODO 3 Declare a local variable datasource of type DataSource follow
	// encapsulation principle
	
	@Autowired
	CarDAO carDAO;

	public JDBCCarDAO() {
	
	}
	

	/**
	 * This method is mapped to VIEW_CAR_LIST_ACTION
	 * @return List list of cars 
	 */
	public List<CarDTO> findAll() {
		List<CarDTO> carList = new ArrayList<CarDTO>();

		carList=carDAO.findAll();

		return carList;
	}


	public void create(CarDTO car)  {
		car.setId(1);
		carDAO.save(car);
		
	}
	

	public void delete(String[] ids) {
		
			for (String string : ids) {
				carDAO.deleteById(Integer.parseInt(string));
			}
			
	}
	
	


	public void update(CarDTO car) {
		CarDTO cars=carDAO.findById(car.getId()).get();
		cars.setId(car.getId());
		cars.setMake(car.getMake());
		cars.setModel(car.getModel());
		cars.setModelYear(car.getModelYear());
		carDAO.save(cars);
	}

	

	 

	public CarDTO findById(int id) {
		CarDTO car=carDAO.findById(id).get();
		return car;
	}
}
